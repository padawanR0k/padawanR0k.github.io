export default {
  "prefers-color-scheme": {
    "title": "유저가 선택한 시스템 테마에 따른 css 분기처리하기"
  }
}
