export default {
  "elb": {
    "title": "CloundFront + ALB 접근제어하기"
  },
  "circleci-glob": {
    "title": "circleCI에서 glob패턴 사용시 주의점"
  }
}
