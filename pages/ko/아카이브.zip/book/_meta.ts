export default {
  "book_uiux": {
    "title": "책 후기 - 사용자를 생각하게하지마"
  }
}
